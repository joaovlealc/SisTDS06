﻿namespace SisTDS06
{
    partial class FormVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLocalizar = new System.Windows.Forms.Button();
            this.lblID_Pedido = new System.Windows.Forms.Label();
            this.txtID_Pedido = new System.Windows.Forms.TextBox();
            this.cbxCliente = new System.Windows.Forms.ComboBox();
            this.lblCliente = new System.Windows.Forms.Label();
            this.lblProduto = new System.Windows.Forms.Label();
            this.cbxProduto = new System.Windows.Forms.ComboBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.lblPreco = new System.Windows.Forms.Label();
            this.btnAdicionar_Produto = new System.Windows.Forms.Button();
            this.btnExcluir_Produto = new System.Windows.Forms.Button();
            this.btnEditar_Pedido = new System.Windows.Forms.Button();
            this.btnNovo_Pedido = new System.Windows.Forms.Button();
            this.btnFinalizar_Pedido = new System.Windows.Forms.Button();
            this.btnAtualizar_Pedido = new System.Windows.Forms.Button();
            this.btnVenda = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.dgvVenda = new System.Windows.Forms.DataGridView();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.txtID_Produto = new System.Windows.Forms.TextBox();
            this.lblID_Produto = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVenda)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLocalizar
            // 
            this.btnLocalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalizar.Location = new System.Drawing.Point(196, 8);
            this.btnLocalizar.Name = "btnLocalizar";
            this.btnLocalizar.Size = new System.Drawing.Size(112, 23);
            this.btnLocalizar.TabIndex = 0;
            this.btnLocalizar.Text = "Localizar Pedido";
            this.btnLocalizar.UseVisualStyleBackColor = true;
            this.btnLocalizar.Click += new System.EventHandler(this.btnLocalizar_Click);
            // 
            // lblID_Pedido
            // 
            this.lblID_Pedido.AutoSize = true;
            this.lblID_Pedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID_Pedido.Location = new System.Drawing.Point(21, 12);
            this.lblID_Pedido.Name = "lblID_Pedido";
            this.lblID_Pedido.Size = new System.Drawing.Size(63, 13);
            this.lblID_Pedido.TabIndex = 1;
            this.lblID_Pedido.Text = "ID Pedido";
            // 
            // txtID_Pedido
            // 
            this.txtID_Pedido.Location = new System.Drawing.Point(90, 10);
            this.txtID_Pedido.Name = "txtID_Pedido";
            this.txtID_Pedido.Size = new System.Drawing.Size(100, 20);
            this.txtID_Pedido.TabIndex = 2;
            // 
            // cbxCliente
            // 
            this.cbxCliente.FormattingEnabled = true;
            this.cbxCliente.Location = new System.Drawing.Point(64, 83);
            this.cbxCliente.Name = "cbxCliente";
            this.cbxCliente.Size = new System.Drawing.Size(300, 21);
            this.cbxCliente.TabIndex = 3;
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliente.Location = new System.Drawing.Point(12, 86);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(46, 13);
            this.lblCliente.TabIndex = 4;
            this.lblCliente.Text = "Cliente";
            // 
            // lblProduto
            // 
            this.lblProduto.AutoSize = true;
            this.lblProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto.Location = new System.Drawing.Point(7, 126);
            this.lblProduto.Name = "lblProduto";
            this.lblProduto.Size = new System.Drawing.Size(51, 13);
            this.lblProduto.TabIndex = 6;
            this.lblProduto.Text = "Produto";
            // 
            // cbxProduto
            // 
            this.cbxProduto.FormattingEnabled = true;
            this.cbxProduto.Location = new System.Drawing.Point(64, 123);
            this.cbxProduto.Name = "cbxProduto";
            this.cbxProduto.Size = new System.Drawing.Size(300, 21);
            this.cbxProduto.TabIndex = 5;
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Location = new System.Drawing.Point(90, 165);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(100, 20);
            this.txtQuantidade.TabIndex = 8;
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidade.Location = new System.Drawing.Point(12, 168);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(72, 13);
            this.lblQuantidade.TabIndex = 7;
            this.lblQuantidade.Text = "Quantidade";
            // 
            // txtPreco
            // 
            this.txtPreco.Location = new System.Drawing.Point(90, 197);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(100, 20);
            this.txtPreco.TabIndex = 10;
            // 
            // lblPreco
            // 
            this.lblPreco.AutoSize = true;
            this.lblPreco.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco.Location = new System.Drawing.Point(44, 201);
            this.lblPreco.Name = "lblPreco";
            this.lblPreco.Size = new System.Drawing.Size(40, 13);
            this.lblPreco.TabIndex = 9;
            this.lblPreco.Text = "Preço";
            // 
            // btnAdicionar_Produto
            // 
            this.btnAdicionar_Produto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar_Produto.Location = new System.Drawing.Point(229, 165);
            this.btnAdicionar_Produto.Name = "btnAdicionar_Produto";
            this.btnAdicionar_Produto.Size = new System.Drawing.Size(119, 23);
            this.btnAdicionar_Produto.TabIndex = 11;
            this.btnAdicionar_Produto.Text = "Adicionar Produto";
            this.btnAdicionar_Produto.UseVisualStyleBackColor = true;
            this.btnAdicionar_Produto.Click += new System.EventHandler(this.btnAdicionar_Produto_Click);
            // 
            // btnExcluir_Produto
            // 
            this.btnExcluir_Produto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir_Produto.Location = new System.Drawing.Point(229, 194);
            this.btnExcluir_Produto.Name = "btnExcluir_Produto";
            this.btnExcluir_Produto.Size = new System.Drawing.Size(119, 23);
            this.btnExcluir_Produto.TabIndex = 12;
            this.btnExcluir_Produto.Text = "Excluir Produto";
            this.btnExcluir_Produto.UseVisualStyleBackColor = true;
            this.btnExcluir_Produto.Click += new System.EventHandler(this.btnExcluir_Produto_Click);
            // 
            // btnEditar_Pedido
            // 
            this.btnEditar_Pedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditar_Pedido.Location = new System.Drawing.Point(229, 223);
            this.btnEditar_Pedido.Name = "btnEditar_Pedido";
            this.btnEditar_Pedido.Size = new System.Drawing.Size(119, 23);
            this.btnEditar_Pedido.TabIndex = 13;
            this.btnEditar_Pedido.Text = "Editar Pedido";
            this.btnEditar_Pedido.UseVisualStyleBackColor = true;
            this.btnEditar_Pedido.Click += new System.EventHandler(this.btnEditar_Pedido_Click);
            // 
            // btnNovo_Pedido
            // 
            this.btnNovo_Pedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovo_Pedido.Location = new System.Drawing.Point(437, 7);
            this.btnNovo_Pedido.Name = "btnNovo_Pedido";
            this.btnNovo_Pedido.Size = new System.Drawing.Size(112, 23);
            this.btnNovo_Pedido.TabIndex = 14;
            this.btnNovo_Pedido.Text = "Novo Pedido";
            this.btnNovo_Pedido.UseVisualStyleBackColor = true;
            this.btnNovo_Pedido.Click += new System.EventHandler(this.btnNovo_Pedido_Click);
            // 
            // btnFinalizar_Pedido
            // 
            this.btnFinalizar_Pedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizar_Pedido.Location = new System.Drawing.Point(437, 36);
            this.btnFinalizar_Pedido.Name = "btnFinalizar_Pedido";
            this.btnFinalizar_Pedido.Size = new System.Drawing.Size(112, 23);
            this.btnFinalizar_Pedido.TabIndex = 15;
            this.btnFinalizar_Pedido.Text = "Finalizar Pedido";
            this.btnFinalizar_Pedido.UseVisualStyleBackColor = true;
            this.btnFinalizar_Pedido.Click += new System.EventHandler(this.btnFinalizar_Pedido_Click);
            // 
            // btnAtualizar_Pedido
            // 
            this.btnAtualizar_Pedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtualizar_Pedido.Location = new System.Drawing.Point(437, 65);
            this.btnAtualizar_Pedido.Name = "btnAtualizar_Pedido";
            this.btnAtualizar_Pedido.Size = new System.Drawing.Size(112, 23);
            this.btnAtualizar_Pedido.TabIndex = 16;
            this.btnAtualizar_Pedido.Text = "Atualizar Pedido";
            this.btnAtualizar_Pedido.UseVisualStyleBackColor = true;
            this.btnAtualizar_Pedido.Click += new System.EventHandler(this.btnAtualizar_Pedido_Click);
            // 
            // btnVenda
            // 
            this.btnVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVenda.Location = new System.Drawing.Point(437, 94);
            this.btnVenda.Name = "btnVenda";
            this.btnVenda.Size = new System.Drawing.Size(112, 23);
            this.btnVenda.TabIndex = 17;
            this.btnVenda.Text = "Venda";
            this.btnVenda.UseVisualStyleBackColor = true;
            this.btnVenda.Click += new System.EventHandler(this.btnVenda_Click);
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(474, 123);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 18;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // dgvVenda
            // 
            this.dgvVenda.AllowUserToAddRows = false;
            this.dgvVenda.AllowUserToDeleteRows = false;
            this.dgvVenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVenda.Location = new System.Drawing.Point(15, 271);
            this.dgvVenda.Name = "dgvVenda";
            this.dgvVenda.ReadOnly = true;
            this.dgvVenda.Size = new System.Drawing.Size(534, 232);
            this.dgvVenda.TabIndex = 19;
            this.dgvVenda.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVenda_CellClick);
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(449, 539);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 21;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(403, 543);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(36, 13);
            this.lblTotal.TabIndex = 20;
            this.lblTotal.Text = "Total";
            // 
            // txtID_Produto
            // 
            this.txtID_Produto.Location = new System.Drawing.Point(94, 43);
            this.txtID_Produto.Name = "txtID_Produto";
            this.txtID_Produto.Size = new System.Drawing.Size(96, 20);
            this.txtID_Produto.TabIndex = 23;
            // 
            // lblID_Produto
            // 
            this.lblID_Produto.AutoSize = true;
            this.lblID_Produto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID_Produto.Location = new System.Drawing.Point(21, 46);
            this.lblID_Produto.Name = "lblID_Produto";
            this.lblID_Produto.Size = new System.Drawing.Size(68, 13);
            this.lblID_Produto.TabIndex = 22;
            this.lblID_Produto.Text = "ID Produto";
            // 
            // FormVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 571);
            this.Controls.Add(this.txtID_Produto);
            this.Controls.Add(this.lblID_Produto);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.dgvVenda);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnVenda);
            this.Controls.Add(this.btnAtualizar_Pedido);
            this.Controls.Add(this.btnFinalizar_Pedido);
            this.Controls.Add(this.btnNovo_Pedido);
            this.Controls.Add(this.btnEditar_Pedido);
            this.Controls.Add(this.btnExcluir_Produto);
            this.Controls.Add(this.btnAdicionar_Produto);
            this.Controls.Add(this.txtPreco);
            this.Controls.Add(this.lblPreco);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.lblQuantidade);
            this.Controls.Add(this.lblProduto);
            this.Controls.Add(this.cbxProduto);
            this.Controls.Add(this.lblCliente);
            this.Controls.Add(this.cbxCliente);
            this.Controls.Add(this.txtID_Pedido);
            this.Controls.Add(this.lblID_Pedido);
            this.Controls.Add(this.btnLocalizar);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormVenda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormVenda";
            this.Load += new System.EventHandler(this.FormVenda_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVenda)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLocalizar;
        private System.Windows.Forms.Label lblID_Pedido;
        private System.Windows.Forms.TextBox txtID_Pedido;
        private System.Windows.Forms.ComboBox cbxCliente;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.Label lblProduto;
        private System.Windows.Forms.ComboBox cbxProduto;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.Label lblPreco;
        private System.Windows.Forms.Button btnAdicionar_Produto;
        private System.Windows.Forms.Button btnExcluir_Produto;
        private System.Windows.Forms.Button btnEditar_Pedido;
        private System.Windows.Forms.Button btnNovo_Pedido;
        private System.Windows.Forms.Button btnFinalizar_Pedido;
        private System.Windows.Forms.Button btnAtualizar_Pedido;
        private System.Windows.Forms.Button btnVenda;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.DataGridView dgvVenda;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox txtID_Produto;
        private System.Windows.Forms.Label lblID_Produto;
    }
}